'use client';

import { useState, useEffect, CSSProperties } from 'react';

/* ─── Design Tokens ──────────────────────────────────────────────── */
const T = {
  bg:         '#07070A',
  bgCard:     '#0E0E12',
  border:     '#1C1C24',
  borderGold: '#C9A84C44',
  gold:       '#C9A84C',
  goldDim:    '#C9A84C18',
  text:       '#F0EDE6',
  textMuted:  '#888880',
  textDim:    '#3C3C44',
  mono:       "'Space Mono', monospace",
  serif:      "'Playfair Display', serif",
  sans:       "'Syne', sans-serif",
} as const;

/* ─── Wealth Score Bands ─────────────────────────────────────────── */
const BANDS = [
  { label: 'STARTER', range: '0–250',    min: 0,   max: 250  },
  { label: 'BUILDER', range: '251–500',  min: 251, max: 500  },
  { label: 'FORGER',  range: '501–750',  min: 501, max: 750  },
  { label: 'ELITE',   range: '751–1000', min: 751, max: 1000 },
];

const TARGET_SCORE = 742;

function getBandLabel(score: number) {
  if (score <= 250) return 'STARTER';
  if (score <= 500) return 'BUILDER';
  if (score <= 750) return 'FORGER';
  return 'ELITE';
}

/* ─── Animated counter hook ──────────────────────────────────────── */
function useCountUp(target: number, duration = 2200, delay = 700) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start: number | null = null;
    let raf: number;
    const timeout = setTimeout(() => {
      const step = (ts: number) => {
        if (!start) start = ts;
        const prog = Math.min((ts - start) / duration, 1);
        const eased = 1 - Math.pow(1 - prog, 3); // ease-out cubic
        setVal(Math.round(eased * target));
        if (prog < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }, delay);
    return () => { clearTimeout(timeout); cancelAnimationFrame(raf); };
  }, [target, duration, delay]);
  return val;
}

/* ─── Success screen ─────────────────────────────────────────────── */
function SuccessView({ email }: { email: string }) {
  return (
    <div style={{
      minHeight: '100vh', background: T.bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: T.sans, padding: '24px',
    }}>
      <div style={{ textAlign: 'center', maxWidth: 460 }}>
        <div style={{
          width: 56, height: 56, borderRadius: '50%',
          background: T.goldDim, border: `1.5px solid ${T.gold}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 24px', fontSize: 22,
        }}>⚡</div>
        <h2 style={{ fontFamily: T.serif, color: T.gold, fontSize: 28, fontWeight: 700, marginBottom: 12, margin: '0 0 12px' }}>
          You&apos;re on the list.
        </h2>
        <p style={{ color: T.textMuted, lineHeight: 1.75, fontSize: 15 }}>
          We&apos;ll notify <strong style={{ color: T.text }}>{email}</strong> when
          WealthForge opens. Your score journey starts soon.
        </p>
        <div style={{
          marginTop: 32, padding: '14px 20px', background: T.bgCard,
          border: `1px solid ${T.border}`, borderRadius: 10, display: 'inline-block',
        }}>
          <span style={{ fontFamily: T.mono, fontSize: 10, color: T.gold, letterSpacing: '0.1em' }}>
            INITIAL WEALTH SCORE UNLOCKS AT LAUNCH
          </span>
        </div>
      </div>
    </div>
  );
}

/* ─── Main component ─────────────────────────────────────────────── */
export default function WaitlistPage() {
  const [email, setEmail]         = useState('');
  const [loading, setLoading]     = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError]         = useState('');
  const score = useCountUp(TARGET_SCORE);
  const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleSubmit = async () => {
    if (!valid || loading) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error('Failed');
      setSubmitted(true);
    } catch {
      setError('Something went wrong — please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) return <SuccessView email={email} />;

  /* ── shared inline style helpers ── */
  const chip: CSSProperties = {
    display: 'inline-flex', alignItems: 'center', gap: 7,
    background: T.goldDim, border: `1px solid ${T.borderGold}`,
    borderRadius: 20, padding: '5px 14px',
  };

  return (
    <div style={{ minHeight: '100vh', background: T.bg, color: T.text, fontFamily: T.sans, overflowX: 'hidden' }}>

      {/* ── Sticky nav ── */}
      <nav style={{
        borderBottom: `1px solid ${T.border}`, padding: '0 24px', height: 56,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        position: 'sticky', top: 0,
        background: `${T.bg}EE`, backdropFilter: 'blur(12px)', zIndex: 100,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{
            width: 26, height: 26, background: T.gold, borderRadius: 6,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, fontSize: 13, color: T.bg,
          }}>W</div>
          <span style={{ fontWeight: 700, letterSpacing: '0.06em', fontSize: 14 }}>WealthForge</span>
        </div>
        <span style={{
          fontSize: 10, color: T.gold, fontFamily: T.mono, letterSpacing: '0.12em',
          border: `1px solid ${T.borderGold}`, padding: '4px 10px', borderRadius: 20,
        }}>COMING SOON</span>
      </nav>

      {/* ── Hero ── */}
      <section style={{ maxWidth: 660, margin: '0 auto', padding: '72px 24px 0', textAlign: 'center' }}>

        {/* Eyebrow */}
        <div style={{ ...chip, marginBottom: 40 }}>
          <span style={{ width: 5, height: 5, borderRadius: '50%', background: T.gold, display: 'inline-block' }} />
          <span style={{ fontSize: 10, color: T.gold, fontFamily: T.mono, letterSpacing: '0.12em' }}>
            AFRICA&apos;S AI WEALTH OPERATING SYSTEM
          </span>
        </div>

        {/* Animated Score — the thesis */}
        <div style={{ marginBottom: 40 }}>
          <div style={{ fontFamily: T.mono, fontSize: 10, color: T.textMuted, letterSpacing: '0.14em', marginBottom: 10 }}>
            YOUR WEALTH SCORE
          </div>
          <div style={{
            fontFamily: T.serif,
            fontSize: 'clamp(80px, 16vw, 120px)',
            fontWeight: 700, color: T.gold, lineHeight: 1, letterSpacing: '-0.02em',
          }}>
            {score}
          </div>
          <div style={{ ...chip, marginTop: 10 }}>
            <span style={{ fontFamily: T.mono, fontSize: 11, color: T.gold, letterSpacing: '0.1em' }}>
              {getBandLabel(score)}
            </span>
          </div>

          {/* Progress bar */}
          <div style={{
            background: T.bgCard, border: `1px solid ${T.border}`,
            borderRadius: 6, height: 6,
            margin: '16px auto 0', maxWidth: 400,
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', inset: '0 auto 0 0',
              width: `${(score / 1000) * 100}%`,
              background: `linear-gradient(90deg, ${T.gold}55, ${T.gold})`,
              borderRadius: 6, transition: 'width 0.05s linear',
            }} />
          </div>

          {/* Band chips */}
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
            gap: 6, marginTop: 12, maxWidth: 400, marginLeft: 'auto', marginRight: 'auto',
          }}>
            {BANDS.map(b => {
              const active = score >= b.min && score <= b.max;
              return (
                <div key={b.label} style={{
                  padding: '8px 4px', borderRadius: 7,
                  background: active ? T.goldDim : 'transparent',
                  border: `1px solid ${active ? T.borderGold : T.border}`,
                  transition: 'all 0.3s',
                }}>
                  <div style={{ fontFamily: T.mono, fontSize: 8, color: active ? T.gold : T.textDim, letterSpacing: '0.08em' }}>
                    {b.label}
                  </div>
                  <div style={{ fontFamily: T.mono, fontSize: 9, color: active ? `${T.gold}99` : T.textDim, marginTop: 1 }}>
                    {b.range}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Headline — proof before promise */}
        <h1 style={{
          fontFamily: T.serif, fontSize: 'clamp(28px, 5vw, 42px)',
          fontWeight: 700, lineHeight: 1.2, margin: '0 0 16px', letterSpacing: '-0.01em',
        }}>
          Your wealth has a number.<br />
          <em style={{ color: T.gold, fontStyle: 'italic' }}>Watch it grow.</em>
        </h1>
        <p style={{
          color: T.textMuted, fontSize: 16, lineHeight: 1.75,
          maxWidth: 440, margin: '0 auto 36px',
        }}>
          WealthForge tracks every financial dimension — savings, debt, habits, goals —
          into one AI-powered score built for the African reality.
        </p>

        {/* Email form */}
        <div style={{ maxWidth: 440, margin: '0 auto 16px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              style={{
                background: T.bgCard, border: `1px solid ${T.border}`,
                borderRadius: 10, padding: '14px 18px', color: T.text,
                fontSize: 15, fontFamily: T.sans, outline: 'none',
                width: '100%', boxSizing: 'border-box',
              }}
            />
            <button
              onClick={handleSubmit}
              disabled={!valid || loading}
              style={{
                background: valid && !loading ? T.gold : `${T.gold}44`,
                color: valid && !loading ? T.bg : `${T.gold}88`,
                border: 'none', borderRadius: 10, padding: '14px 28px',
                fontSize: 15, fontWeight: 700, letterSpacing: '0.04em',
                cursor: valid && !loading ? 'pointer' : 'not-allowed',
                fontFamily: T.sans, transition: 'all 0.2s',
              }}
            >
              {loading ? 'Joining...' : 'Join the Waitlist →'}
            </button>
          </div>
          {error && <p style={{ color: '#E05C5C', fontSize: 13, marginTop: 8, fontFamily: T.sans }}>{error}</p>}
          <p style={{ fontSize: 12, color: T.textDim, marginTop: 10, fontFamily: T.sans }}>
            No spam. POPIA compliant. Unsubscribe anytime.
          </p>
        </div>
      </section>

      {/* ── Feature tiles ── */}
      <section style={{ maxWidth: 660, margin: '0 auto', padding: '56px 24px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 12 }}>
          {[
            { icon: '🧠', title: 'AI Wealth Coach',  body: 'Knows stokvel, lobola, and SA tax. Context-first advice.' },
            { icon: '📊', title: 'Wealth Score',     body: 'One number across savings, debt, habits, and goals.' },
            { icon: '🔐', title: 'POPIA Compliant',  body: 'Built in South Africa, for South Africa. Your data stays yours.' },
            { icon: '🇿🇦', title: 'ZAR Native',      body: 'Every rand tracked, every subscription priced locally.' },
          ].map(f => (
            <div key={f.title} style={{
              background: T.bgCard, border: `1px solid ${T.border}`,
              borderRadius: 12, padding: '20px 16px',
            }}>
              <div style={{ fontSize: 22, marginBottom: 10 }}>{f.icon}</div>
              <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 6, letterSpacing: '0.01em' }}>{f.title}</div>
              <div style={{ fontSize: 12, color: T.textMuted, lineHeight: 1.6 }}>{f.body}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Founding member strip ── */}
      <section style={{ maxWidth: 660, margin: '0 auto', padding: '0 24px 80px', textAlign: 'center' }}>
        <div style={{ borderTop: `1px solid ${T.border}`, paddingTop: 40 }}>
          <p style={{ fontFamily: T.mono, fontSize: 10, color: T.textDim, letterSpacing: '0.1em', margin: 0 }}>
            EARLY ACCESS · LIMITED SPOTS · FORGER PLAN FREE FOR FOUNDING MEMBERS
          </p>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer style={{
        borderTop: `1px solid ${T.border}`, padding: '20px 24px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexWrap: 'wrap', gap: 8,
      }}>
        <span style={{ fontSize: 11, color: T.textDim, fontFamily: T.mono }}>© 2025 WEALTHFORGE</span>
        <span style={{ fontSize: 11, color: T.textDim, fontFamily: T.mono }}>JOINWEALTHFORGE.COM</span>
      </footer>
    </div>
  );
}
