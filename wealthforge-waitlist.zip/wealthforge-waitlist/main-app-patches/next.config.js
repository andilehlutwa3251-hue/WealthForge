/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',

  // Monorepo: hoist shared packages
  transpilePackages: [
    '@wealthforge/ui',
    '@wealthforge/shared',
    '@wealthforge/types',
  ],

  experimental: {
    serverActions: {
      allowedOrigins: ['joinwealthforge.com', 'localhost:3000'],
    },
  },

  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Frame-Options',        value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy',        value: 'strict-origin-when-cross-origin' },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
