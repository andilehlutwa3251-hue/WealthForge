#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  WealthForge — Full Deployment Script
#  Run from the wealthforge-waitlist/ directory
#  Prerequisites: node >= 18, npm, git, vercel CLI
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
log()  { echo -e "${GREEN}▶ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }
fail() { echo -e "${RED}✗ $1${NC}"; exit 1; }

# ── 0. Prereqs ───────────────────────────────────────────────────────
command -v node >/dev/null 2>&1 || fail "Node.js not found. Install from https://nodejs.org"
command -v npm  >/dev/null 2>&1 || fail "npm not found"
command -v git  >/dev/null 2>&1 || fail "git not found"

log "Installing Vercel CLI..."
npm i -g vercel@latest 2>/dev/null || warn "vercel CLI already installed"

# ── 1. Install deps ──────────────────────────────────────────────────
log "Installing dependencies..."
npm install

# ── 2. Collect env vars ──────────────────────────────────────────────
echo ""
echo "────────────────────────────────────────────────"
warn "You need two values from Klaviyo before continuing:"
echo "  1. Private API Key  → https://www.klaviyo.com/account#api-keys-tab"
echo "  2. List ID          → Create a 'WealthForge Waitlist' list, copy the ID"
echo "────────────────────────────────────────────────"
echo ""
read -rp "Klaviyo Private API Key: " KLAVIYO_API_KEY
read -rp "Klaviyo List ID:         " KLAVIYO_LIST_ID

# Write local .env for test build
cat > .env.local <<EOF
KLAVIYO_API_KEY=${KLAVIYO_API_KEY}
KLAVIYO_LIST_ID=${KLAVIYO_LIST_ID}
EOF

# ── 3. Test build locally ────────────────────────────────────────────
log "Running test build..."
npm run build || fail "Build failed — fix errors above before deploying"
log "Build passed ✓"

# ── 4. Git init & first commit ───────────────────────────────────────
if [ ! -d ".git" ]; then
  log "Initialising git repo..."
  git init
  git add .
  git commit -m "feat: WealthForge waitlist — initial deploy"
else
  log "Git repo exists, committing any changes..."
  git add .
  git diff --staged --quiet || git commit -m "chore: deploy update"
fi

# ── 5. Vercel login ──────────────────────────────────────────────────
log "Checking Vercel auth..."
vercel whoami 2>/dev/null || vercel login

# ── 6. Link / create Vercel project ─────────────────────────────────
log "Linking to Vercel project..."
vercel link --yes --project wealthforge-waitlist 2>/dev/null || \
  vercel --yes --name wealthforge-waitlist

# ── 7. Set environment variables ─────────────────────────────────────
log "Pushing env vars to Vercel..."
for ENV in production preview; do
  echo "$KLAVIYO_API_KEY" | vercel env add KLAVIYO_API_KEY  "$ENV" --yes 2>/dev/null || \
    echo "$KLAVIYO_API_KEY" | vercel env add KLAVIYO_API_KEY  "$ENV"
  echo "$KLAVIYO_LIST_ID"  | vercel env add KLAVIYO_LIST_ID  "$ENV" --yes 2>/dev/null || \
    echo "$KLAVIYO_LIST_ID"  | vercel env add KLAVIYO_LIST_ID  "$ENV"
done
log "Env vars set ✓"

# ── 8. Deploy to production ──────────────────────────────────────────
log "Deploying to production..."
DEPLOY_URL=$(vercel --prod --yes 2>&1 | tail -n1)
log "Deployed: ${DEPLOY_URL}"

# ── 9. DNS instructions ──────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════════════"
echo -e "${GREEN}  ✓ DEPLOYED${NC}"
echo "════════════════════════════════════════════════════════════════"
echo ""
echo "Next: point joinwealthforge.com → Vercel in Cloudflare"
echo ""
echo "  In Vercel dashboard:"
echo "    Settings → Domains → Add 'joinwealthforge.com'"
echo "    Copy the CNAME value Vercel gives you"
echo ""
echo "  In Cloudflare DNS:"
echo "    Type:   CNAME"
echo "    Name:   @"
echo "    Target: cname.vercel-dns.com   (or whatever Vercel shows)"
echo "    Proxy:  OFF (grey cloud) until SSL verified, then ON"
echo ""
echo "  For www redirect, add:"
echo "    Type:   CNAME"
echo "    Name:   www"
echo "    Target: cname.vercel-dns.com"
echo "    Proxy:  OFF initially"
echo ""
echo "  Health check: ${DEPLOY_URL}/api/health"
echo "════════════════════════════════════════════════════════════════"
