import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { email } = await req.json();

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Invalid email' }, { status: 400 });
    }

    const apiKey  = process.env.KLAVIYO_API_KEY;
    const listId  = process.env.KLAVIYO_LIST_ID;

    if (!apiKey || !listId) {
      console.error('Missing KLAVIYO_API_KEY or KLAVIYO_LIST_ID');
      return NextResponse.json({ error: 'Server misconfigured' }, { status: 500 });
    }

    const res = await fetch(
      'https://a.klaviyo.com/api/profile-subscription-bulk-create-jobs/',
      {
        method: 'POST',
        headers: {
          Authorization:  `Klaviyo-API-Key ${apiKey}`,
          'Content-Type': 'application/json',
          revision:       '2024-02-15',
        },
        body: JSON.stringify({
          data: {
            type: 'profile-subscription-bulk-create-job',
            attributes: {
              list_id:       listId,
              subscriptions: [
                {
                  channels: { email: ['MARKETING'] },
                  email,
                  profile: {
                    data: {
                      type: 'profile',
                      attributes: {
                        email,
                        properties: {
                          source:     'WealthForge Waitlist',
                          signup_date: new Date().toISOString(),
                        },
                      },
                    },
                  },
                },
              ],
            },
          },
        }),
      }
    );

    if (!res.ok) {
      const body = await res.text();
      console.error('Klaviyo error:', res.status, body);
      return NextResponse.json({ error: 'Subscription failed' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('Waitlist route error:', err);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
