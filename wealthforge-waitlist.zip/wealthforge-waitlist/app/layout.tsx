import type { Metadata } from 'next';
import './globals.css';

/* Fonts are self-hosted via @fontsource — bundled in node_modules,
   zero external requests at build time or runtime. */

export const metadata: Metadata = {
  title: "WealthForge — Africa's AI Wealth Operating System",
  description:
    "Build real wealth. Measure every step. Join the waitlist for WealthForge — Africa's AI-powered wealth OS with a Wealth Score from 0–1000.",
  openGraph: {
    title:       'WealthForge',
    description: "Africa's AI Wealth Operating System",
    url:         'https://joinwealthforge.com',
    siteName:    'WealthForge',
    type:        'website',
  },
  twitter: {
    card:        'summary_large_image',
    title:       'WealthForge',
    description: "Africa's AI Wealth Operating System",
  },
  icons: { icon: '/favicon.ico' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
